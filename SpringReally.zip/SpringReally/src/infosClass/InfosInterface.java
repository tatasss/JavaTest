package infosClass;

public interface InfosInterface {

	String genererInfos();

}
