package infosClass;

public class InfosXML implements InfosInterface{
	public InfosXML(){}
	@Override
	public String genererInfos() {
		return "<BaliseXML>Infos</BaliseXML>";
	}

}
